<?php
	 require get_theme_file_path('/inc/custom-route.php');
	 require get_theme_file_path('/inc/db.php');
 
