<?php
add_action('rest_api_init','custom_Search');
/* ________________________________________________________________________________________________________________*/
function custom_Search()
{
    // register_rest_route('db','connect',array(
    //     'methods'=>' GET',
    //     'callback'=>'connectResults'
    // ));
    // //////////////////////////////////////////
    // register_rest_route('bp/v1','search',array(
    //     'methods'=>' GET',
    //     'callback'=>'customSearchResults'
    // ));
    //  //////////////////////////////////////////
    //  register_rest_route('bp/v1','db',array(
    //     'methods'=>' POST',
    //     'callback'=>'DB_CRUD_Handler'
    // ));
}
/* ________________________________________________________________________________________________________________*/
function connectResults() 
{
    Return 'ok';
}
/* ________________________________________________________________________________________________________________*/
function customSearchResults() 
{
    Return 'it is your new route';
}
/* ________________________________________________________________________________________________________________*/
function DB_CRUD_Handler($request)
{
      /* Get data from the request
  //  $data = $request->get_json_params();
 
*/
    create_table();

// $arr = json_decode('[{"var1":"9","var2":"16","var3":"16"},{"var1":"8","var2":"15","var3":"15"}]');

// foreach($arr as $item) { //foreach element in $arr
//     $uses = $item['var1']; //etc
// }

//     $updated_post = array(
//     'SIS' => $request['cmd_str'],
//     'DIA' => 'B',
//     'PUL' => 'C'
//     );
 
    // $updated_post = array(
    //     'SIS' => $request['Sistolic'],
    //     'DIA' => $request['DIA'],
    //     'PUL' => $request['PUL']
    // );

    Return     "Table created";         //$updated_post;
}
/* ________________________________________________________________________________________________________________*/
function create_table() 
{
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'ems';
    $sql = "DROP TABLE IF EXISTS $table_name;
            CREATE TABLE $table_name(
            id mediumint(11) NOT NULL AUTO_INCREMENT,
            emp_id varchar(50) NOT NULL,
            emp_name varchar (250) NOT NULL,
            emp_email varchar (250) NOT NULL,
            emp_dept varchar (250) NOT NULL,
            PRIMARY KEY id(id)
            )$charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

 