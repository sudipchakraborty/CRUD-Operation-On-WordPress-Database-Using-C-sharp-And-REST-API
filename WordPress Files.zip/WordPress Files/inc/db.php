<?php
add_action('rest_api_init','db_Handle');

global $wpdb;
$charset_collate = $wpdb->get_charset_collate();
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
/* ________________________________________________________________________________________________________________*/
function db_Handle()
{
    register_rest_route('bp','v1',array(
        'methods'=>'GET',
        'callback'=>'db_cmd_Execute'
    ));

    register_rest_route('bp','v1',array(
        'methods'=>'POST',
        'callback'=>'db_cmd_Execute'
    ));
}
/* ________________________________________________________________________________________________________________*/
function db_cmd_Execute($request) 
{
    $cmd= $request["cmd"];
    $cmd_str=$request["cmd_string"]; 
    ////////////////////////////////
    if($cmd=="connect")
    {
        Return 'ok';
    }
    ////////////////////////////////
    else if($cmd=="create")
    {
        dbDelta($cmd_str.$charset_collate);
        return "<Table Created>";
    }
    ////////////////////////////////
    else if($cmd=="insert")
    {
        global $wpdb;
        $wpdb->insert($request["tbl_name"], [
            "User_ID" => $request["User_ID"],
            "DateTime" => $request["DateTime"],          
            'SIS' => $request["SIS"],
            'DIA' =>$request["DIA"],
            'PUL' => $request["PUL"]
        ]);
        if ($wpdb->insert_id > 0) 
        {
            return "Insert Successfully";
        } else 
        {
            return "Failed to Insert data";
        }
    }
    ////////////////////////////////5
    else if($cmd=="read")
    {
        // Access the database
        global $wpdb;

        // Initialize an empty array to store the data
        $dataArray = array();

        // Example: Query to retrieve all posts
        $posts = $wpdb->get_results("SELECT * FROM wp_bp2");
        
        // Loop through the posts
        foreach ($posts as $post) {
            // Store data in the array
            $dataArray[] = array
            (
                'id'        => $post->id,
                'User_ID'   => $post->User_ID,
                'DateTime'  => $post->DateTime,
                'SIS'       => $post->SIS,
                'DIA'       => $post->DIA,
                'PUL'       => $post->PUL,
            );
        }
        return $dataArray;
    }
    ////////////////////////////////
    else if($cmd=="update")
    {
        global $wpdb;

            if (!empty($request['id'])) 
            {
                $wpdb->update
                (
                    $request["tbl_name"], 
                    ["User_ID" => $request['User_ID'], 
                    'DateTime' => $request['DateTime'], 
                    'SIS' => $request['SIS'], 
                    'DIA' => $request['DIA'], 
                    'PUL' => $request['PUL']],
                    ["id" => $request['id']]
                );
            }           
            return "Successfully Updated";
    }  
    ////////////////////////////////
    else if($cmd=="delete_row")
    {
        global $wpdb;

        if (!empty($request['id']))
        {
            $wpdb->delete
            ( 
                $request["tbl_name"], 
                array('id' => $request['id']) 
            );              
        }           
        return "Successfully Deleted";
    }
    ////////////////////////////////
    else if($cmd=="delete_table")
    {
        global $wpdb;

        $posts = $wpdb->get_results("drop table wp_bp2");

        // $wpdb->delete
        // ( 
        //     $request["tbl_name"]
        // );                            
        return $posts;//"Table Deleted";
    }
    ////////////////////////////////
    else
    {
        return "Other DB Operation command";
    }
}